<?php include_once('include/header.php'); ?>

  <!-- Page Content -->
  <div class="container">
  
	<h1 class="my-4">Administration - Nouvelles</h1>

	<p><b>En construction. On présume que cette partie serait réalisée dans une phase ultérieure.</b></p> 

	Il doit cependant être impossible d'accéder à cette page sans être préalablement connecté. 
	Si un utilisateur non connecté essaie d'accéder à la page, un message d'erreur doit s'afficher
	
  </div>

<?php include_once('include/footer.php'); ?>