<div class="d-flex flex-column">
    <h2><?= $nouvelle->titre ?></h2>
    <span><?= $nouvelle->date_nouvelle ?></span>
    <p><?= $nouvelle->description_longue ?></p>
</div>