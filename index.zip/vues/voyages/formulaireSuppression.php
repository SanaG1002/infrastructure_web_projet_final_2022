<h4> <?= $voyage->titre ?></h4>
<p><?= $voyage->duree ?></p>
<p><?= $voyage->description ?></p>

<form method="POST">
    <button name="boutonSupprimer" type="submit">Supprimer le voyage</button><br>
</form>